# React Native
-keep class com.facebook.react.** { *; }
-keep class com.facebook.hermes.** { *; }
-keep class com.facebook.jni.** { *; }
-keep class com.facebook.soloader.** { *; }

# BitAim overlay classes — never obfuscate these
-keep class com.bitaim.carromaim.overlay.** { *; }
-keep class com.bitaim.carromaim.capture.** { *; }
-keep class com.bitaim.carromaim.cv.** { *; }
-keep class com.bitaim.carromaim.MainActivity { *; }
-keep class com.bitaim.carromaim.MainApplication { *; }

# OpenCV — native JNI methods must not be renamed
-keep class org.opencv.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**
